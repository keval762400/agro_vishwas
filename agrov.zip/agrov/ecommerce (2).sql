-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 04, 2024 at 08:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `userpassword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `userpassword`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `Firstname` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` int(10) NOT NULL,
  `Message` varchar(10000) NOT NULL,
  `Username` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Firstname`, `Email`, `Phone`, `Message`, `Username`) VALUES
('keval', 'kuku@gmail.com', 1234567890, 'hyy my name is keval', 'kuku'),
('nikunj', 'nikunj@gmail.com', 1234567890, 'hyy ', 'bodakiya'),
('mahek', 'mahel@gmail.com', 2147483647, 'hyy my name is mahek', 'bodakiya');

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `id` int(10) NOT NULL,
  `Pname` varchar(100) NOT NULL,
  `Pprice` varchar(100) NOT NULL,
  `image` varchar(200) NOT NULL,
  `Pcategory` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`id`, `Pname`, `Pprice`, `image`, `Pcategory`) VALUES
(1, 'seeds', '343', 'Uploadimage/dragon.jpg', 'seeds'),
(3, 'frouth', '200', 'Uploadimage/apple.jpg', 'seeds'),
(4, 'soyabean', '500', 'Uploadimage/soyabean.jpg', 'seeds'),
(5, 'monokoto', '250', 'Uploadimage/monokoto.jpg', 'fertilizer'),
(7, 'talptri', '144', 'Uploadimage/tarpaulin.jpg', 'hardware'),
(11, 'keval', '00', 'Uploadimage/aditya.jpg', 'Home'),
(12, 'tourch', '499', 'Uploadimage/tourch.jpg', 'Home'),
(13, 'talapatri', '999', 'Uploadimage/tarpaulin.jpg', 'Home'),
(14, 'contaf', '649', 'Uploadimage/contaf.jpg', 'Home'),
(15, 'aditya', '870', 'Uploadimage/aditya.jpg', 'fertilizer'),
(16, 'npk', '1099', 'Uploadimage/npk.jpg', 'fertilizer'),
(17, 'chemical-npk-fertilizer', '699', 'Uploadimage/chemical-npk-fertilizer-.webp', 'fertilizer'),
(19, 'wheat', '499', 'Uploadimage/wheat11.jpg', 'seeds'),
(20, 'tourch', '450', 'Uploadimage/tourch2.jpg', 'hardware'),
(21, 'taperoll', '250', 'Uploadimage/taperoll.jpg', 'hardware'),
(22, 'pump', '2500', 'Uploadimage/pump2.jpg', 'hardware');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `Id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Number` varchar(200) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`Id`, `UserName`, `Email`, `Number`, `Password`) VALUES
(8, 'keval', 'keval1@gmail.com', '1234567890', '123'),
(9, 'mihir', 'mihir@gmail.com', '1234567890', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `UserName` (`UserName`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblproduct`
--
ALTER TABLE `tblproduct`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
