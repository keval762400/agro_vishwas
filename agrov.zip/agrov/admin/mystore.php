<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home Page</title>
    <link rel="stylesheet" href="mystore.css" type="text/css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        nav {
            position: sticky;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: rgb(62, 63, 62);
            padding: 15px;
            width: 100%;
            height: max-content;
            text-shadow: 1px 1px 1px #000;
        }

        .logo {
            color: blueviolet;
            font-size: 1.3em;
            padding: 15px;
            border: none;
            border-radius: 50px;
        }

        .menu ul {
            display: flex;
            gap: 10px;
            cursor: pointer;
        }

        .menu ul li {
            list-style: none;
        }

        .menu ul li a {
            text-decoration: none;
            font-size: 1.7em;
            color: white;
            padding: 10px;
        }

        .menu ul li a:hover {
            background-color: rgb(24, 3, 34);
            transition: all 0.5s ease-in-out;
            border-radius: 10px;
        }

        .btn3 {
            display: flex;
            gap: 15px;
        }

        .btn3 a {
            color: white;
            font-size: 1.2em;
            padding: 10px 20px;
            background-color: #007bff;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .btn3 a:hover {
            background-color: #0056b3;
        }

        h2 {
            
            text-align: center;
            margin: 30px 0;
            border-bottom: 4px solid blue;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            margin: 30px;
            padding: 10px;
            background-color: black;
        }

        .action-buttons a {
            color: white;
            margin: 0 50px;
            text-decoration: none;
            font-size: 1.7em;
        }

        .action-buttons a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<?php
session_start();
if(!$_SESSION['admin']){
    header("location:form/login.php");
}
?>

<body>

<nav>
    <div class="container">
        <div class="logo">
            <img src="logo.png" alt="Your Logo" style="max-width: 300px; height: auto;">
        </div>
        <div class="btn3">
            <a href="login.php">Hello, <?php echo $_SESSION['admin']; ?></a>
            <a href="form/logout.php">Logout</a>
            <a href="../user/index.php">User Panel</a>
        </div>
    </div>
</nav>

<div>
    <h2>Welcom To Dashboard</h2>
</div>

<div class="action-buttons">
    <a href="product/index.php">Add Post</a>
    <a href="user.php">User</a>
</div>

</body>
</html>
