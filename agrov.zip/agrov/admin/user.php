<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Design</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: white;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        thead {
            background-color: #007bff;
            color: white;
        }

        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        a {
            text-decoration: none;
            color: white;
            padding: 8px 12px;
            background-color: #dc3545;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        a:hover {
            background-color: #c82333;
        }

        
        .total-container {
            margin-top: 20px;
            text-align: center;
            background-color: #007bff;
            color: white;
            padding: 10px;
            border-radius: 8px;
        }

        .total-container h1 {
            font-size: 2.5em;
            margin: 0;
        }

        .total-container h2 {
            font-size: 1.5em;
            margin-bottom: 10px;
        }

        
        @media (max-width: 768px) {
            table, thead, tbody, th, td, tr {
                display: block;
                width: 100%;
            }

            thead {
                display: none;
            }

            tr {
                margin-bottom: 15px;
                background-color: white;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            }

            td {
                display: flex;
                justify-content: space-between;
                padding: 12px;
                border: none;
                border-bottom: 1px solid #ddd;
                text-align: right;
            }

            td::before {
                content: attr(data-label);
                font-weight: bold;
                text-transform: uppercase;
                flex-basis: 50%;
                text-align: left;
                padding-right: 10px;
            }
        }
    </style>
</head>
<body>

<?php

$con = mysqli_connect('localhost', 'root', '', 'ecommerce');
$Record = mysqli_query($con, "SELECT * FROM `tbluser`");
$row_count = mysqli_num_rows($Record);
?>

<div>
    <table>
        <thead>
            <tr>
                <th>Serial NO.</th>
                <th>Name</th>
                <th>Email</th>
                <th>Number</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 0;
            while($row = mysqli_fetch_array($Record)){
                echo "
                <tr>
                    <td>{$row['Id']}</td>
                    <td>{$row['UserName']}</td>
                    <td>{$row['Email']}</td>
                    <td>{$row['Number']}</td>
                    <td><a href='delete.php?ID={$row['Id']}'>Delete</a></td>
                </tr>
                ";
            }
            ?>
        </tbody>
    </table>
</div>

<div class="total-container">
    <h2>Total Users</h2>
    <h1><?php echo $row_count; ?></h1>
</div>

</body>
</html>
