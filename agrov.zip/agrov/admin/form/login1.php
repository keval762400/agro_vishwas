<?php
$con = mysqli_connect('localhost', 'root', '', 'ecommerce');

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['username']) && isset($_POST['userpassword'])) {
    $A_name = $_POST['username'];
    $A_password = $_POST['userpassword'];

    
    $result = mysqli_query($con, "SELECT * FROM `admin` 
    WHERE username = '$A_name' AND userpassword = '$A_password'");

    session_start();

    if (mysqli_num_rows($result) > 0) {

        $_SESSION['admin'] =  $A_name;

        echo "
        <script>
        alert('Login successfully');
        window.location.href='../mystore.php';
        </script>
        ";
    } else {
        echo "
        <script>
        alert('Invalid user/password');
        window.location.href='login.php';
        </script>
        ";
    }
} else {
    echo "
    <script>
    alert('Please enter username and password');
    window.location.href='login.php';
    </script>
    ";
}

mysqli_close($con); 
?>
