<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>
    <style>
        body {
          font-size: 20px;
            font-family: Arial, sans-serif; /* Set a clean font for the entire page */
            background-color: #f9f9f9; /* Light background for the body */
            margin: 0; /* Remove default body margin */
            padding: 20px; /* Add padding around the body */
        }

        h1 {
            text-align: center;
            margin: 30px 0;
            padding: 10px;
            font-size: 2em; /* Increased font size for better visibility */
            color: #333; /* Dark color for the heading */
        }

        .form-container {
            text-align: center;
            margin: 40px auto;
            padding: 20px;
            background-color: white; /* White background for the form */
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
            width: 80%; /* Responsive width */
            max-width: 600px; /* Maximum width for larger screens */
        }

        .form-group {
            margin: 20px 0; /* Spacing between form groups */
        }

        label {
            font-size: 1.1em; /* Label font size */
            margin-right: 10px; /* Space between label and input */
        }

        input[type="text"],
        input[type="file"],
        select {
            padding: 10px; /* Padding inside inputs and select */
            width: 80%; /* Input width */
            border: 1px solid #ddd; /* Light border */
            border-radius: 4px; /* Rounded corners for inputs */
            font-size: 1em; /* Font size for inputs */
            margin-left: 10px; /* Space between label and input */
        }

        button {
            padding: 10px 20px; /* Padding inside button */
            background-color: red; /* Button background color */
            color: white; /* Button text color */
            border: none; /* Remove default border */
            border-radius: 4px; /* Rounded corners for button */
            font-size: 1.1em; /* Button font size */
            cursor: pointer; /* Pointer cursor on hover */
        }

        button:hover {
            background-color: darkred; /* Darker red on hover */
        }
    </style>
</head>
<body>

    <h1>Product Detail</h1>

    <div class="form-container">
        <form action="insert.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="Pname">Product Name:</label>
                <input type="text" name="Pname" placeholder="NAME" required>
            </div>

            <div class="form-group">
                <label for="Pprice">Product Price:</label>
                <input type="text" name="Pprice" placeholder="PRICE" required>
            </div>

            <div class="form-group">
                <label for="image">Add Product Image:</label>
                <input type="file" name="image" required>
            </div>

            <div class="form-group">
                <label for="Pages">Select Page Category:</label>
                <select name="Pages" required>
                <option value="Home">Home</option>
                    <option value="seeds">Seeds</option>
                    <option value="fertilizer">Fertilizer</option>
                    <option value="hardware">Hardware</option>
                </select>
            </div>

            <button name="submit">Upload</button>
        </form>
    </div>

</body>
</html>


    
                     <!-- FETCH DATA -->
              
                     <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Table</title>
    <style>
        
        table {
            width: 80%; 
            margin: 20px auto; 
            border-collapse: collapse;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); 
        }

        
        thead th {
            background-color: #f2f2f2;
            padding: 10px;
            border: 1px solid #ddd;
            font-weight: bold;
            text-align: center;
        }

    
        tbody td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
            vertical-align: middle;
        }

        
        tbody td img {
            width: 100px;
            height: auto;
            border-radius: 5px; 
        }

        
        tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        
        tbody tr:hover {
            background-color: #f1f1f1;
        }

        
        @media (max-width: 768px) {
            table {
                width: 100%;
            }

            tbody td img {
                width: 80px; 
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Image</th>
                            <th>Category</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'Config.php';
                        $Record = mysqli_query($con, "SELECT * FROM `tblproduct`");
                        while ($row = mysqli_fetch_array($Record)) {
                            echo "
                            <tr>
                                <td>$row[id]</td>
                                <td>$row[Pname]</td>
                                <td>$row[Pprice]</td>
                                <td><img src='$row[image]' alt='Product Image'></td>
                                <td>$row[Pcategory]</td>
                                <td><button><a href='delete.php? ID=$row[id]'>Delete</a></button></td>

                            </tr>
                            ";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>
