<?php
if (isset($_POST['submit'])) {
    include 'Config.php'; 

    $product_name = $_POST['Pname'];
    $product_price = $_POST['Pprice'];
    $product_image = $_FILES['image'];

    
    $image_loc = $_FILES['image']['tmp_name'];
    $image_name = $_FILES['image']['name'];
    $image_des = "Uploadimage/".$image_name;


    move_uploaded_file($image_loc, $image_des);

    $product_category = $_POST['Pages'];


    $query = "INSERT INTO `tblproduct` (`Pname`, `Pprice`, `image`, `Pcategory`) 
              VALUES ('$product_name', '$product_price', '$image_des', '$product_category')";

    mysqli_query($con, $query) or die(mysqli_error($con));
    header("location:index.php");
}
?>


