<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Update</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 50px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2em;
            color: #333;
        }

        .form-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 40px 30px;
            width: 100%;
            max-width: 500px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-size: 1.1em;
            color: #555;
        }

        input[type="text"], input[type="file"], select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 1em;
            box-sizing: border-box;
            outline: none;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="file"]:focus, select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 1.1em;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #218838;
        }


        @media (max-width: 600px) {
            .form-container {
                padding: 20px;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>

<?php
        echo $id = $_GET['id'];
        include 'Config.php';
        $Record = mysqli_query($con, "SELECT * FROM `tblproduct` WHERE id = $id ");
        $data = mysqli_fetch_array($Record);
    ?>
    
    <div class="form-container">
        <h1>Product Update</h1>
        <form action="update.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="Pname">Product Name:</label>
                <input type="text" value="<?php echo $data ['Pname']?>" name="Pname" placeholder="NAME" required>
            </div>

            <div class="form-group">
                <label for="Pprice">Product Price:</label>
                <input type="text"  value="<?php echo $data ['Pprice']?>" name="Pprice" placeholder="PRICE" required>
            </div>

            <div class="form-group">
                <label for="image">Add Product Image:</label>
                <input type="file" name="image" required><br>
                <img src="<?php echo $data ['image']?>" alt="">
            </div>

            <div class="form-group">
                <label for="Pages">Select Page Category:</label>
                <select name="Pages" required>
                    <option value="seeds">Home</option>
                    <option value="seeds">Seeds</option>
                    <option value="fertilizer">Fertilizer</option>
                    <option value="hardware">Hardware</option>
                </select>
            </div>

            <input type="hidden" name="id" value="<?php echo $data ['id']?>">
            <button name="submit">Update</button>
        </form>
    </div>

    
 

<?php
if(isset($_POST['update'])){
       $id = $_POST['id'];
    $product_name = $_POST['Pname'];
    $product_price = $_POST['Pprice'];
    $product_image = $_FILES['image'];

    
    $image_loc = $_FILES['image']['tmp_name'];
    $image_name = $_FILES['image']['name'];
    $image_des = "Uploadimage/".$image_name;

    
    move_uploaded_file($image_loc, $image_des);

    $product_category = $_POST['Pages'];
    include 'Config.php';
    mysqli_query($con, "UPDATE `tblproduct` SET
    `Pname`='$product_name',`Pprice`='$product_price',`image`='$image_des',
     `Pcategory`='$product_category' WHERE id = $id");

     header("locaton:index.php");
}

?>

   
</body>
</html>
