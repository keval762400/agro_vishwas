<?php
session_start(); // Start the session before any HTML or output
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Cart</title>
    <?php include 'header.php'; ?>
    <style>
    
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-top: 20px;
        }


        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        td {
            color: #555;
        }

    
        button {
            width: 150px
            ;
            height: 50px;
            padding: 8px 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        
        tr:hover {
            background-color: #f1f1f1;
        }

        
        @media (max-width: 768px) {
            table {
                width: 100%;
            }

            th, td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>

    <h1>My Cart</h1>
    <table>
        <thead>
            <tr>
                <th>Index No.</th>
                <th>Product Name</th>
                <th>Product Price</th>
                <th>Product Quantity</th>
                <th>Total Price</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $total = 0;
            if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
                $index = 1;
                foreach ($_SESSION['cart'] as $key => $value) {
                    
                    $productPrice = (float)$value['productPrice'];
                    $productQuantity = (int)$value['productQuantity'];
                    
                    $total_price = $productPrice * $productQuantity;
                    $total += $total_price;

                    echo "
                    <form action='InsertCart.php' method='POST'>
                        <tr>
                            <td>{$index}</td>
                            <td>{$value['productName']}</td>
                            <td>₹ {$productPrice}</td>
                            <td>{$productQuantity}</td>
                            <td>₹ {$total_price}</td>
                            <td>
                                <input type='hidden' name='productName' value='{$value['productName']}'>    
                            <td>
                                <input type='hidden' name='item' value='{$value['productName']}'>
                                <button type='submit' name='remove'>Delete</button>
                            </td>
                        </tr>
                    </form>
                    ";
                    $index++; 
                }
            } else {
                echo "<tr><td colspan='7'>Your cart is empty.</td></tr>";
            }
            ?>
        </tbody>
    </table>
    <style>
        .h2{
            margin-top: 50px;
            background-color: black;
            color: white;
        }
       .h1{
        margin-top: 20px;
        margin-bottom: 50px;
        border: solid green;
        box-shadow: 19px 19px 30px ;
       }

    </style>
    
    <h2 class="h2">TOTAL</h2>
    <h1 class="h1"><?php echo $total ?></h1>
    

<?php include 'footer.php'; ?>

</body>
</html>
