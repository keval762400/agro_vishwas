<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        .footcontainer {
            display: flex;
            justify-content: space-around;
            background-color: rgb(151, 146, 146);
            padding: 20px;
        }

        .agrovishwas, .agrovishwas2, .agrovishwas3 {
            width: max-content;
            height: max-content;
        }

        footer h1 {
            font-size: 1.5em;
            color: black;
        }

        footer p {
            font-size: 1em;
            color: black;
            margin-bottom: 10px;
        }

        footer {
            background-color: rgb(151, 146, 146);
            padding: 20px 0;
        }

        .agrovishwas p, .agrovishwas2 p, .agrovishwas3 p {
            color: black;
        }

        .agrovishwas p {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <footer>
        <div class="footcontainer">
            <div class="agrovishwas">
                <h1>Agro Vishwas</h1><br>
                <p>206, Pramukh Cypruss,<br>Gandhinagar Bypass Road,</p><br>
                <p>Urjanagar 1, Kudasan,</p><br>
                <p>123 Main Street, Anytown, CA 90001</p><br>
                <p>+91 099646656</p><br>
            </div>

            <div class="agrovishwas2">
                <h1>Services</h1><br>
                <p>Agriculture Hardware's</p><br>
                <p>Pesticides</p><br>
                <p>Fertilizer</p><br>
                <p>Seeds</p><br>
            </div>

            <div class="agrovishwas3">
                <h1>Links</h1><br>
                <p>About Us</p><br>
                <p>Contact Us</p><br>
                <p>Gallery</p><br>
                
            </div>
        </div>
    </footer>
</body>
</html>
