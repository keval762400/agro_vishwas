<?php
$con = mysqli_connect("localhost","root","","ecommerce") or die(mysqli_connect_error());

if($_SERVER['REQUEST_METHOD'] == "POST") {
    $Firstname = $_POST['Firstname'];
    $Username = $_POST['Username'];
    $Email = $_POST['Email'];
    $Phone = $_POST['Phone'];
    $Message = $_POST['Message'];

    
    if(!empty($Firstname) && !empty($Username) && !empty($Email) && !empty($Phone) && !empty($Message)) {
        $query = "insert into contact (Firstname, Username, Email, Phone, Message) values 
        ('$Firstname', '$Username', '$Email', '$Phone', '$Message')";

        mysqli_query($con, $query);

        echo "<script type='text/javascript'> alert('Successfully registered');</script>";
       header("Location: index.php");
       exit();
    } else {
        echo "<script type='text/javascript'> alert('Please provide valid values');</script>";
    }
}
?>

<html>
<head>
    <link rel="stylesheet" href="contact.css" type="text/css">
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        
        .main {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin: auto;
        }

    
        .main h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

    
        .main label {
            font-weight: bold;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }

        
        .main input[type="text"],
        .main input[type="email"],
        .main input[type="tel"],
        .main textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        
        .main button {
            background-color: #28a745;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }

        .main button:hover {
            background-color: #218838;
        }

    
        .main textarea {
            height: 100px;
        }

    
        @media (max-width: 500px) {
            .main {
                width: 90%;
            }
        }
    </style>
</head>

<body>
    <div class="main">
        <form method="POST">
            <h2>Contact</h2>
            <label>Firstname</label>
            <input type="text" name="Firstname" required> <br>

            <label>Surname</label>
            <input type="text" name="Username" required> <br>

            <label>Email</label>
            <input type="email" name="Email" required> <br>

            <label>Phone</label>
            <input type="tel" name="Phone" required> <br>

            <label>Message</label>
            <textarea name="Message" required></textarea> <br>

            <button type="submit" name="submit">Submit</button>
        </form>
    </div>
</body>
</html>
