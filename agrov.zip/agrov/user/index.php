<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home-Page</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            padding: 20px;
        }

        h1 {
            color: #333;
            font-size: 2.5em;
            margin-bottom: 20px;
        }

        p {
            font-size: 1.2em;
            color: #555;
            line-height: 1.6;
        }

        .body1, .body2 {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 50px;
            background-color: #fff;
            margin-bottom: 50px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .content {
            max-width: 50%;
        }

        .content2 {
            max-width: 50%;
        }

        .button button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 1em;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .button button:hover {
            background-color: #218838;
        }

        .img, .img2 {
            max-width: 45%;
        }

        .img img, .img2 img {
            width: 100%;
            height: auto;
            object-fit: cover;
        }

        .title {
            text-align: center;
            margin: 50px 0;
        }

        .title h1 {
            font-size: 2.5em;
            color: #28a745;
        }

        .container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .card {
            display: inline-block;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 18rem;
            margin: 20px;
            overflow: hidden;
            text-align: left;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-bottom: 1px solid #ddd;
        }

        .card-body {
            padding: 15px;
        }

        .card-title {
            text-align: center;
            font-size: 1.5em;
            margin-bottom: 10px;
            color: #333;
        }

        .card-text {
            text-align: center;
            font-size: 1em;
            color: #666;
            margin-bottom: 15px;
        }

        .btn {
            display: block;
            width: 100%;
            text-align: center;
            background-color: #007bff;
            color: #fff;
            padding: 10px 0;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
            font-size: 1em;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .card p {
            font-size: 1.3em;
            color: #555;
            margin-bottom: 20px;
            text-align: center;
        }

        input[type='number'] {
            width: 60px;
            margin-right: 10px;
            padding: 5px;
            text-align: center;
        }

        input[type='submit'] {
            background-color: #28a745;
            color: white;
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type='submit']:hover {
            background-color: #218838;
        }

        
        @media (max-width: 768px) {
            .body1, .body2 {
                flex-direction: column;
            }

            .img, .img2 {
                max-width: 100%;
                margin-bottom: 30px;
            }

            .content, .content2 {
                max-width: 100%;
            }

            .card {
                width: 100%;
            }
        }

        @media (max-width: 480px) {
            .card {
                width: 100%;
            }
        }
    </style>

    <?php include 'header.php'; ?>
</head>
<body>

<div class="body1">
    <div class="content">
        <h1>WELCOME TO AGRICULTURE FARM</h1>
        <h1>Pure Agriculture Products</h1>
        <p>Agrovishwas offers farmers a comprehensive range of agricultural inputs, all aimed at enhancing the efficiency and productivity of their farms.</p>
        <p>Farmers can explore and purchase a diverse selection of products to suit their needs.</p>
        <p>Our platform serves as a valuable resource for all your agricultural queries.</p>
        <div class="button">
            <a href="contact.php">
                <button>Contact Us Now</button>
            </a>
        </div>
    </div>
    <div class="img">
        <img src="../user/f1.png" alt="Hero Image">
    </div>
</div>

<div class="body2">
    <div class="img2">
        <img src="../user/f2.png" alt="Agriculture Image">
    </div>
    <div class="content2">
        <h1>Your Hub for Agricultural Products and Expert Advice</h1>
        <p>Agrovishwas offers farmers a comprehensive range of agri inputs to address their various farm-related concerns.</p>
        <p>Our platform serves as a valuable resource for farmers seeking assistance with any agricultural queries.</p>
        <div class="button">
            <a href="contact.php">
                <button>Contact Us Now</button>
            </a>
        </div>
    </div>
</div>

<div class="title">
    <h1>Our Products</h1>
</div>

<div class="container">
    <?php
    include 'Config.php';
    $Record = mysqli_query($con, "SELECT * FROM tblproduct");
    while ($row = mysqli_fetch_array($Record)) {
        $check_page = $row['Pcategory'];
        if($check_page === 'Home') {
            echo "
            <div class='card'>
            <form action='Insertcart.php' method='POST'>
                <img src='../admin/product/$row[image]' class='card-img-top' alt='$row[Pname]'>
                <div class='card-body'>
                    <h5 class='card-title'>$row[Pname]</h5>
                    <p class='card-text'></p>
                    <p>₹ $row[Pprice]</p>
                    <input type='hidden' name='Pname' value='$row[Pname]'>
                    <input type='hidden' name='Pprice' value='$row[Pprice]'>
                    <input type='number' name='quantity' min='1' max='20' placeholder='Quantity'>
                    <input type='submit' name='addcart' value='BUY'>
                </div>
            </form>
            </div>
            ";
        }
    }
    ?>


</div>
<?php include 'footer.php'; ?>
</body>
</html>
