<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'header.php'; ?>
    <title>Fertilizer</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f4f4f9;
        }

        .title {
            text-align: center;
            margin: 50px 0;
        }

        h1 {
            font-size: 2.5em;
            color: black;
            padding: 20px;
            background-color: #e0ffe0;
            border-radius: 5px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .card {
            display: inline-block;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 18rem;
            margin: 20px;
            overflow: hidden;
            text-align: left;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-bottom: 1px solid #ddd;
        }

        .card-body {
            padding: 15px;
        }

        .card-title {
            text-align: center;
            font-size: 1.5em;
            margin-bottom: 10px;
            color: #333;
        }

        .card-text {
            text-align: center;
            font-size: 1em;
            color: #666;
            margin-bottom: 15px;
        }

        .btn {
            display: block;
            width: 100%;
            text-align: center;
            background-color: #007bff;
            color: #fff;
            padding: 10px 0;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
            font-size: 1em;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .card p {
            font-size: 1.3em;
            color: #555;
            margin-bottom: 20px;
            text-align: center;
        }

        input[type='number'] {
            width: 60px;
            margin-right: 10px;
            padding: 5px;
            text-align: center;
        }

        input[type='submit'] {
            background-color: #28a745;
            color: white;
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type='submit']:hover {
            background-color: #218838;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                align-items: center;
            }

            .card {
                width: 90%;
            }
        }

        @media (max-width: 480px) {
            .card {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="title">
    <h1>Seeds</h1>
</div>

<div class="container">
    <?php
    include 'Config.php';
    $Record = mysqli_query($con, "SELECT * FROM tblproduct");
    while ($row = mysqli_fetch_array($Record)) {
        $check_page = $row['Pcategory'];
        if($check_page === 'seeds'){
            echo "
            <div class='card'>
            <form action='Insertcart.php' method='POST'>
                <img src='../admin/product/$row[image]' class='card-img-top' alt='$row[Pname]' />
                <div class='card-body'>
                    <h5 class='card-title'>$row[Pname]</h5>
                    <p class='card-text'></p>
                    <p>₹ $row[Pprice]</p>

                    <input type='hidden' name='Pname' value='$row[Pname]' />
                    <input type='hidden' name='Pprice' value='$row[Pprice]' />

                    <input type='number' name='quantity' min='1' max='20' placeholder='Quantity' />
                    <input type='submit' name='addcart' value='BUY' />
                </div>
            </form>
            </div>";
        }
    }
    ?>
</div>

<?php include 'footer.php'; ?>
</body>
</html>
