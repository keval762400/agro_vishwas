<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="" type="text/css">
    <style>
         /* <input type='hidden' name='item' value='{$value['productName']}'> */


        /* MENU */


        * {
            /* margin: 0;
            padding: 0; */
            box-sizing: border-box;
        }

        body {
            width: 100%;
            font-family: Arial, sans-serif; 
            background-color: #f2f2f2; 
        }

        nav {
            position: sticky;
            top: 0;
            left: 0;
        }

        .container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            background-color: rgb(62, 63, 110); 
            padding: 5px;
            width: 100%;
            height: max-content;
            text-shadow: 1px 1px 1px #000;
        }

        .logo {
            color: blueviolet;
            font-size: 1.3em;
            padding: 15px;
            border: none;
            border-radius: 50px;
        }

        .menu ul {
            display: flex; 
            text-decoration: none;
            gap: 10px; 
            cursor: pointer; 
        }

        .menu ul li {
            list-style: none; 
        }

        .menu ul li a {
            text-decoration: none; 
            font-size: 1.7em; 
            color: white; 
            padding: 10px; 
        }

        .menu ul li a:hover {
            background-color: rgb(24, 3, 34); 
            transition: all 0.5s ease-in-out; 
            border-radius: 10px; 
        }

        h2 {
            text-align: center; 
            margin: 30px; 
            border-bottom: 4px solid blue; 
        }

        .action-buttons {
            display: flex; 
            justify-content: center; 
            margin: 30px; 
            background-color: black; 
            padding: 10px; 
            font-size: 1.7em; 
        }

        .action-buttons a {
            color: white; 
            margin: 0 50px; 
            text-decoration: none; 
        }

        .btn3 {
            display: flex; 
            gap: 10px; 
        }

                    /* SUBMENU */



                    .submenu {
    background-color: black; 
    padding: 10px; 

}

.submenu .container {
    background-color: black; 

    display: flex; 
    justify-content: space-around; 
    align-items: center; 
}

.submenu a {
    color: white; 
    text-decoration: none; 
    font-size: 1.2em; 
    padding: 8px 15px; 
    border-radius: 5px; 
    transition: background-color 0.3s ease-in-out; 
}

.submenu a:hover {
    background-color: green; 
}
    

        
    </style>
</head>




<body>
<?php




$count = 0;
if (isset($_SESSION['cart'])) {
    $count = count($_SESSION['cart']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="" type="text/css">
    <style>
        
    </style>
</head>
<body>

<nav>
    <div class="container">
        <div class="logo">
            <img src="logo.png" alt="Your Logo" style="max-width: 300px; height: auto;"/>
        </div>
        <div class="menu">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="fertilizer.php">Fertilizer</a></li>
                <li><a href="seeds.php">Seeds</a></li>
                <li><a href="hardware.php">Hardware</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>
    </div>

    <div class="submenu">
        <div class="container">
            <a href="#">
                Hello,
                <?php
                
                if (isset($_SESSION['user'])) {
                    echo $_SESSION['user'];
                    
                    echo '<a href="form/logout.php">Logout</a>';
                } else {
                
                    echo "Guest";
                    echo '<a href="form/login.php">Login</a>';
                }
                ?>
            </a>
            <a href="index.php">Home</a>

            <a href="ViewCart.php">Cart (<?php echo $count; ?>)</a>
            <a href="../admin/form/login.php">Admin</a>
        </div>
    </div>
</nav>

</body>
</html>
