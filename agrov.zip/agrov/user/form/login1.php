




<?php
session_start();
$con = mysqli_connect('localhost', 'root', '', 'ecommerce');

$Name = $_POST['name'];
$Password = $_POST['password'];

$result = mysqli_query($con, "SELECT * FROM `tbluser` 
WHERE (UserName = '$Name' OR Email = '$Name') AND Password = '$Password'");

if (mysqli_num_rows($result)) {
    $_SESSION['user'] = $Name; 
    echo "
    <script>
        alert('Successfully logged in');
        window.location.href = '../index.php';
    </script>
    ";
} else {
    echo "
    <script>
        alert('Incorrect email/password/username');
        window.location.href = 'login.php';
    </script>
    ";
}
?>
