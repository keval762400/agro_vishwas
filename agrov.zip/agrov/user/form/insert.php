<?php

$con = mysqli_connect('localhost', 'root', '', 'ecommerce');

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $Email = $_POST['email'];
    $Number = $_POST['number'];
    $Password = $_POST['password'];

    
    $Dup_Email = mysqli_query($con, "SELECT * FROM `tbluser` WHERE Email = '$Email'");
    $Dup_username = mysqli_query($con, "SELECT * FROM `tbluser` WHERE UserName = '$name'");

    
    if (mysqli_num_rows($Dup_Email) > 0) {
        echo "
        <script>
            alert('This Email is already taken');
            window.location.href = 'register.php';
        </script>
        ";
    } 
    
    elseif (mysqli_num_rows($Dup_username) > 0) {
        echo "
        <script>
            alert('This username is already taken');
            window.location.href = 'register.php';
        </script>
        ";
    } 
    
    else {
        mysqli_query($con, "INSERT INTO `tbluser`( `UserName`, `Email`, `Number`, `Password`) 
        VALUES ('$name', '$Email', '$Number', '$Password')");

        echo "
        <script>
            alert('Registration successful');
            window.location.href = 'login.php';
        </script>
        ";
    }
}

?>
