<?php
session_start(); 
if(isset($_SESSION['user'])){

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

$product_name = $_POST['Pname'];
$product_price = $_POST['Pprice'];
$product_quantity = isset($_POST['quantity']) ? $_POST['quantity'] : 1;

if (isset($_POST['addcart'])) {
    
    $check_product = array_column($_SESSION['cart'], 'productName');
    
    if (in_array($product_name, $check_product)) {
        echo "
           <script>
           alert('Product already added');
           window.location.href = 'index.php';
           </script>
        ";
    } else {
        $_SESSION['cart'][] = array(
            'productName' => $product_name,
            'productPrice' => $product_price,
            'productQuantity' => $product_quantity
        );

        header('Location: ViewCart.php');
        exit();
    }
}

if (isset($_POST['remove'])) {
    foreach ($_SESSION['cart'] as $key => $value) {
        if ($value['productName'] == $_POST['item']) {
            unset($_SESSION['cart'][$key]); // Correct the syntax here
            $_SESSION['cart'] = array_values($_SESSION['cart']); // Reindex array after removal
            header('Location: ViewCart.php');
            exit();
        }
    }
}

}
else{
    header("location:form/login.php");
}
?>
